import { useState, useEffect } from 'react'
import './App.css'
import { supabase } from './supabase'

function App() {
  useEffect(() => {
  async function cargarSesiones() {
    const { data, error } = await supabase
      .from('sesiones')
      .select('*')

  if (error) {
  console.error(error)
} else {
  setSesiones(data)
}
}

  cargarSesiones()
}, [])
const [sesiones, setSesiones] = useState([])
const meses = [
  ...new Set(
    sesiones.map((sesion) =>
      new Date(sesion.fecha).toLocaleDateString("es-ES", {
        month: "long",
      }).toUpperCase()
    )
  ),
]

const [sesionAbierta, setSesionAbierta] = useState(null)
const [nombre, setNombre] = useState("")
const [correo, setCorreo] = useState("")
const [tema, setTema] = useState("")
const normalizarTexto = (texto) =>
  texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()

const temasSimilares = sesiones.filter(
  (s) =>
    s.tema &&
    tema.trim().length >= 3 &&
    normalizarTexto(s.tema).includes(normalizarTexto(tema))
)

  return (
<div className="app">
  <h1>Sesiones Docentes Urgencias</h1>
  <h2>Servicio de Urgencias</h2>

  <p className="intro">
    Reserva una sesión haciendo clic sobre una fecha disponible.
  </p>

  <div className="aviso">
    <strong>⚠️ IMPORTANTE</strong>
    <p>
      Una vez confirmada la reserva, la fecha quedará bloqueada y no podrá
      modificarse desde la aplicación.
    </p>
  </div>

<h3>Próximas sesiones</h3>

{meses.map((mes) => (
  <div key={mes}>

    <h3>{mes}</h3>

    {sesiones
      .filter(
  (sesion) =>
    new Date(sesion.fecha).toLocaleDateString("es-ES", {
      month: "long",
    }).toUpperCase() === mes
)
      .map((sesion) => (
        <div
  className={`tarjeta ${!sesion.reservada ? "disponible" : "reservada"}`}
  key={sesion.fecha}
>

<h4>
  {new Date(sesion.fecha).toLocaleDateString("es-ES", {
    day: "numeric",
    month: "long",
    year: "numeric",
  })}
</h4>

<div className={!sesion.reservada ? "estado disponible-badge" : "estado reservada-badge"}>
  {!sesion.reservada ? "DISPONIBLE" : "RESERVADA"}
</div>
{!sesion.reservada && (
  <>
    <button
      className="boton-reservar"
      onClick={() =>
  setSesionAbierta(
    sesionAbierta === sesion.fecha ? null : sesion.fecha
  )
}
    >
      Reservar
    </button>

    {sesionAbierta === sesion.fecha && (
<form className="formulario">

  <label htmlFor="nombre">Nombre y apellidos</label>
  <input
    id="nombre"
    type="text"
    autoComplete="off"
    value={nombre}
    onChange={(e) => setNombre(e.target.value)}
  />

  <label htmlFor="correo">Correo electrónico</label>
  <input
    id="correo"
    type="email"
    autoComplete="off"
    value={correo}
    onChange={(e) => setCorreo(e.target.value)}
  />

  <label htmlFor="tema">Tema</label>
  <input
    id="tema"
    type="text"
    autoComplete="off"
    value={tema}
    onChange={(e) => setTema(e.target.value)}
  />
{temasSimilares.length > 0 && (
  <div className="temas-similares">
    <strong>🟡 Ya existen sesiones con un título similar:</strong>

    <ul>
      {temasSimilares.map((s) => (
        <li key={s.fecha}>{s.tema}</li>
      ))}
    </ul>
  </div>
)}
<div className="confirmacion">

<h4>⚠️ Importante</h4>

<p>
  Una vez confirmada la reserva, la fecha quedará bloqueada y no podrá modificarse desde la aplicación.
</p>

  <button
  type="button"
  className="boton-confirmar"
  onClick={async () => {
  console.log("BOTÓN PULSADO", sesion)

  if (!nombre.trim()) {
    alert("Introduce tu nombre y apellidos.")
    return
  }

  if (!correo.trim()) {
    alert("Introduce tu correo electrónico.")
    return
  }

  if (!correo.includes("@")) {
    alert("Introduce un correo electrónico válido.")
    return
  }

  if (!tema.trim()) {
    alert("Introduce el tema de la sesión.")
    return
  }

  const { error } = await supabase
    .from("sesiones")
    .update({
      ponente: nombre,
      correo: correo,
      tema: tema,
      reservada: true,
      fecha_reserva: new Date().toISOString(),
    })
    .eq("id", sesion.id)

if (error) {
  console.error(error)
  alert(JSON.stringify(error))
  return
}
console.log("Entrando en UPDATE", sesion.id)
  const { data } = await supabase
    .from("sesiones")
    .select("*")
    .order("fecha")

  setSesiones(data)

  setSesionAbierta(null)
  setNombre("")
  setCorreo("")
  setTema("")
  }}
>
  Confirmar reserva
</button>

</div>

</form>
)}
</>
)}
          {sesion.reservada && (
            <>
              <p><strong>Ponente:</strong> {sesion.ponente}</p>
              <p><strong>Tema:</strong> {sesion.tema}</p>
            </>
          )}

        </div>
      ))}

  </div>
))}



</div>
  )
}
export default App